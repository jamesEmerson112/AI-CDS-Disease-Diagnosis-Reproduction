CS2V.py: Main class 

util_cy.c: class containing all methods inmplemented through Cython

utils: folder containing utility files

entity: folder containing utility-class exploiting in CS2V

Dataset: folder containing a portion of dataset explited

Symptoms-Diagnosis.txt: example of a text file containing symptoms and diagnosis